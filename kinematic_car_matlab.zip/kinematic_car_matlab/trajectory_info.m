syms t;
y1d=sin(t/300);
y2d=cos(t/300);

dy1d=diff(y1d,1)
ddy1d=diff(y1d,2)
dddy1d=diff(y1d,3)
dy2d=diff(y2d,1)
ddy2d=diff(y2d,2)
dddy2d=diff(y2d,3)