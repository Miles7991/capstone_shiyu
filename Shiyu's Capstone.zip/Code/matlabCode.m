function [outputs] = functionName(inputs)
  %{
    This is a Comment Block
    That
    can
    span
    multiple
    lines.
  %}
  
  % This is a regular comment
  a = 1 + 2 * sin(angle);
  b = 'This is a String';